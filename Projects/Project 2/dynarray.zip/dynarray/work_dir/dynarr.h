#include <cassert>
#include <iostream>
#include <string>

class RuntimeException // generic run-time exception
{
 protected:
  std::string errorMsg;
 public:
  RuntimeException(const std::string& err) { errorMsg = err; }
  std::string getMessage() const { return errorMsg; }
};

class InvalidIndex : public RuntimeException
{
 public:
  InvalidIndex(const std::string& err): RuntimeException(err) {};
};

template <class dynElem>
class dynarr {
  private:
    int capacity;
    dynElem *A;
  public:
    dynarr() : capacity(0), A(NULL) {};
    dynarr(int N): capacity(N), A(new dynElem[N]){}
    dynarr(const dynarr<dynElem> &other);
    ~dynarr();
    dynarr<dynElem> & operator=( const dynarr<dynElem> &other);
    dynElem & operator[](int ndx);
    int getCapacity();
    void reserve(int newcap);
    // if newcap <= capacity, does nothing; 
    // if capacity is 0, allocates a dynamic array of
    // capacity newcap and makes A point to that array;
    // otherwise allocates a new dynamic array newA of capacity 
    // newcap, copies values in A to newA, deletes A and sets
    // A equal to newA
};

template <class dynElem>
dynarr<dynElem>::dynarr(const dynarr<dynElem> &other)
{

}

template <class dynElem>
dynarr<dynElem>::~dynarr()
{

}

template <class dynElem>
dynarr<dynElem> & dynarr<dynElem>::operator=( const dynarr<dynElem> &other)
{
  
}
  
template <class dynElem>
dynElem & dynarr<dynElem>::operator[](int ndx) throw(InvalidIndex)
{

}

template <class dynElem>
int dynarr<dynElem>::getCapacity()
{

}
  
template <class dynElem>
void dynarr<dynElem>::reserve(int newcap)
{

}

