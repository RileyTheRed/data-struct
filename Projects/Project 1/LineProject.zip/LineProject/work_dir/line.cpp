// line.cpp
// Author: <replace_this_with_your_name!>

#include <iostream>
#include "line.h"


const char * EqualLines::what() const throw()
{
  // supply the code below
  
} 

const char *ParallelLines::what() const throw ()
{
  // supply the code below
  
};

double Line::intersect(const Line L) const
{
  // supply the code below
  
} 

